function myFunction() {
			  location.replace("Payment.html")
			}
