function myFunction() {
			  location.replace("Home.html")
			}
