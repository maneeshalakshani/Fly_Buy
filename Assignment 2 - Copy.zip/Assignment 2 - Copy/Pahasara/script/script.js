function myFunction() {
			  location.replace("../AddCart.html")
			}
			
	function mfunction(){
	location.replace("../DeliveryDetails.html")
}